#ifndef NODE_H
#define NODE_H

#include <iostream>
#include <cstdlib>

using namespace std;

struct node {
    int val;
    node *next;
};

#endif
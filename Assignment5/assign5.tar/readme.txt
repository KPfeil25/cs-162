Name: Kevin Pfeil
Description: This is my linked list implementation. You will be 
allowed to enter a number into the list
with either push_front, push_back, or insert. 
It will then ask if you want to sort the list in ascending or descending order
and print out how many prime numbers are in the list (repeats included).

Also,
Whichever TA grades me, thanks for your help! I was at office hours
what seemed like everyday so there is a high chance you helped me out.
I could not have gotten through this class without you guys.
Thanks a million!
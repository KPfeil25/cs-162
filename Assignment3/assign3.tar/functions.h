#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <cstdlib>
#include "animal.h"

int get_random_event();
int get_random_species();
float get_random_percent();

#endif